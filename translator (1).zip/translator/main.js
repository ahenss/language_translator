let langOption = document.querySelectorAll('select');
let fromText = document.querySelector('.fromText');
let transText = document.querySelector('.toTranslate');
let fromVoice = document.querySelector('.from');
let toVoice = document.querySelector('.to');

langOption.forEach((get, con) =>{
    for(let countryCode in language){

        let selected;
        if(con == 0 && countryCode == "en-GB"){
            selected = "selected";
        }else if(con == 1 && countryCode == "bn-IN"){
            selected = "selected";
        }

        let option = `<option value="${countryCode}" ${selected}>${language[countryCode]}</option>`;
        get.insertAdjacentHTML('beforeend', option);
    }
    })

    fromText.addEventListener('input', function() {
        let content = fromText.ariaValueMax;
        fromcontent = langOption[0].value;
        transContent= langOption[1].value;

        let transINK = `https://api.mymemory.translated.net/get?q=${content}!&langpair=${fromcontent}|${transContent}`;

        fetch(transINK).then(translate => translate.json()).then(data =>{
            transText.value = data.responseData.translatedText;
        
        })
    })

    fromVoice.addEventListener('click', function(){
        cosole.log('icon clicked')
    })

    fromVoice.addEventListener('click',function() {
        let fromTalk;
        fromTalk = new SpeechSynthesisUtterance(fromText.value);
        fromTalk.lang = langOption[0].value;
        speechSynthesis.speak(fromTalk) 
    })

    
    toVoice.addEventListener('click',function() {
        let fromTalk;
        fromTalk = new SpeechSynthesisUtterance(transTextText.value);
        fromTalk.lang = langOption[1].value;
        speechSynthesis.speak(fromTalk) 
    })

    

    